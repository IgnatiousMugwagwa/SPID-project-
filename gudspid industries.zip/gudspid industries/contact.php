<?php

if (isset($_POST['submit'])){

	$FirstName = $_POST['FirstName'];

	$Surname = $_POST['surname'];

	$mailFrom = $_POST['mail'];

	$subject = $_POST['subject'];

	$message = $_POST['message'];

	$mailTo ="info@gudspidindustries.co.zw";

	$headers = "From: ".$mailFrom;
	$txt = " You have received an email from ".$name.".\n\n".$message;

	mail($mailTo, $subject, $txt, $headers );

	header("location:contact.html");

}
